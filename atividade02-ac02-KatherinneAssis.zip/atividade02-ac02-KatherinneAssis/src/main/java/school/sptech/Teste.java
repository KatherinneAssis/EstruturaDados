package school.sptech;

import java.util.Scanner;

public class Teste {
  public static void main(String[] args) {
    ListaObj<InstituicaoEnsino> instituicoes = new ListaObj<>(5);

    Scanner scanner = new Scanner(System.in);
    Scanner scannerNl = new Scanner(System.in);

    int opcao;
    do {
      System.out.println("Menu:");
      System.out.println("1 - Adicionar um objeto na lista (cadastro)");
      System.out.println("2 - Exibir os objetos cadastrados (relatório)");
      System.out.println("3 - Fim do programa (encerrar)");
      System.out.print("Escolha uma opção: ");
      opcao = scanner.nextInt();


      switch (opcao) {
        case 1:
          System.out.println("Informe os dados do brinquedo: \n");

          System.out.print("ID: ");
          int id = scanner.nextInt();

          System.out.print("Ano fundação: ");
          int anoFundacao = scanner.nextInt();

          System.out.print("Nome: ");
          String nome = scannerNl.nextLine();

          System.out.print("Mensalidade: ");
          double mensalidade = scanner.nextDouble();

          System.out.print("Endereço: ");
          String endereco = scannerNl.nextLine();

          System.out.print("Numero de Alunos: ");
          int numeroAlunos = scanner.nextInt();

          System.out.print("Possui Laboratório (true/false): ");
          boolean possuiLaboratorio = scanner.nextBoolean();

          instituicoes.adiciona(new InstituicaoEnsino(id, anoFundacao, nome, mensalidade, endereco, numeroAlunos, possuiLaboratorio));
          break;


        case 2:
          System.out.println("\n Relatório das Instituições: \n");
          System.out.printf("%-5s %-15s %-10s %-10s %-20s %-15s %-10s%n", "Id", "AnoFundacao", "Nome", "Mensalidade", "Endereco", "NumeroAlunos", "PossuiLaboratorio");
          for (int i = 0; i < instituicoes.getTamanho(); i++) {
            InstituicaoEnsino instituicao = instituicoes.getElemento(i);
            System.out.printf("%-5d %-15d %-10.2f %-10s %-20s %-15s %-10b%n",
                    instituicao.getId(), instituicao.getAnoFundacao(), instituicao.getMensalidade(),
                    instituicao.getNome(), instituicao.getEndereco(), instituicao.getNumeroAlunos(), instituicao.getPossuiLaboratorio());
          }
          break;


        case 3:
          System.out.println("Encerrando o programa...");
          break;


        default:
          System.out.println("Opção inválida! Por favor, escolha uma opção válida.");
      }
    } while (opcao != 3);
    scanner.close();
  }
}
package school.sptech;

public class InstituicaoEnsino {
    private int id;
    private int anoFundacao;
    private String nome;
    private double mensalidade;
    private String endereco;
    private int numeroAlunos;
    private boolean possuiLaboratorio;

    public InstituicaoEnsino(int id, int anoFundacao, String nome, double mensalidade, String endereco, int numeroAlunos, boolean possuiLaboratorio) {
        this.id = id;
        this.anoFundacao = anoFundacao;
        this.nome = nome;
        this.mensalidade = mensalidade;
        this.endereco = endereco;
        this.numeroAlunos = numeroAlunos;
        this.possuiLaboratorio = possuiLaboratorio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAnoFundacao() {
        return anoFundacao;
    }

    public void setAnoFundacao(int anoFundacao) {
        this.anoFundacao = anoFundacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getMensalidade() {
        return mensalidade;
    }

    public void setMensalidade(double mensalidade) {
        this.mensalidade = mensalidade;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getNumeroAlunos() {
        return numeroAlunos;
    }

    public void setNumeroAlunos(int numeroAlunos) {
        this.numeroAlunos = numeroAlunos;
    }

    public boolean getPossuiLaboratorio() {
        return possuiLaboratorio;
    }

    public void setPossuiLaboratorio(boolean possuiLaboratorio) {
        this.possuiLaboratorio = possuiLaboratorio;
    }
}
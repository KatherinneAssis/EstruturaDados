[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/z-khZSsW)
## Atividade - Lista Genérica e Saída Formatada
### 1)  Complete a classe ListaObj até que passe em 100% dos testes

### 2) Dentro do projeto criado: 
- Crie uma classe de tema livre, baseada nos temas sorteados dos exercícios da Sprint 1 (temas no fim da página).
- A classe deve conter os atributos a seguir, não necessariamente nessa ordem: 
  - id (inteiro) 
  - outro inteiro a sua escolha,  
  - pelo menos um String,  
  - pelo menos um Double (ou double)  
  - pelo menos mais 3 atributos do tipo de sua escolha 
- (no total deve haver pelo menos 7 atributos) 

### Observações:  
- Os atributos deverão estar encapsulados, implemente o construtor que inicializa os atributos, os setters e getters e o toString().  
- Os atributos devem fazer sentido dentro do contexto da classe escolhida. 

### 3) Na classe Teste, no método main: 

- Crie uma lista que deverá ser objeto da ListaObj<ClasseTemaEscolhido> (pode ter tamanho 5) 
- Implemente dentro do main um laço de repetição com menu onde o usuário pode escolher as seguintes opções: 
  - Opção 1 - Adicionar um objeto na lista (cadastro).
  - Opção 2 - Exibir os objetos cadastrados (relatório).
  - Opção 3 - Fim do programa (encerrar).

### Importante:
- A opção 2 do menu deverá exibir os objetos cadastrados na lista, de forma que os dados fiquem em colunas, bem alinhados, levando em consideração que números são alinhados para a direita e textos são alinhados para a esquerda. 
- Não se esqueça dos títulos das colunas. 
- Use o método printf para exibir. 

## Temas: 
  1. Futebol
  2. Musica
  3. Comida
  4. Automovel
  5. Imovel
  6. Atleta
  7. Heroi
  8. Vilao
  9. ProgramaDeTV
  10. Brinquedo
  11. Empresa
  12. Pessoa
  13. InstituicaoFinanceira
  14. Animal
  15. Profissao
  16. Politica
  17. RedesSociais
  18. InstituicaoDeEnsino
  19. Entretenimento
  20. Filme
  21. Serie
  22. DesenhoAnimado
  23. VideoGame
  24. JogosDeComputador
  25. Doenca
  26. Investimento
  27. Loja
  28. Pet
  29. MeioDeTransporte
  30. Roupa
  31. Remedio
  32. Vacina
  33. Livro
  34. Bebida
  35. Eletronico
  36. Viagem
  37. Hospital
  38. Evento
   

public interface IPagamento {
    double pagamento();
    double pagamentoFinal();
}